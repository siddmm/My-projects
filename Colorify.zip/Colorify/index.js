function paint(color) {
  const circle = document.getElementById('circleID');
  circle.style = `background-color:${color}`;
}