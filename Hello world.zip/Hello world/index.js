.body{
	text-color: red;
}
console.log("Hello World");